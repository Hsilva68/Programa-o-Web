<?php

header('Location: https://dog.ceo/dog-api/');
exit();
